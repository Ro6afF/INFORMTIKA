#pragma once

#define GFW__INLINE [[gnu::always_inline]] inline

namespace gfw{

using uint=unsigned;
using ullong=unsigned long long;

}
